<?php
	$conn= mysqli_connect('localhost', 'root', '','perpustakaan2');
	
	$id_pinjam=$_GET['id_pinjam'];
	$hapus="delete from peminjaman where id_pinjam='$id_pinjam'";
	$data=mysqli_query($conn,$hapus);
	
	if($data > 0){
		echo "
		<script>
		alert('data berhasil di hapus');
		document.location.href='edit_peminjaman.php';
		</script>";
	}else
		echo "
		<script>
		alert('data gagal di hapus');
		document.location.href='edit_peminjaman.php';
		</script>";
?>