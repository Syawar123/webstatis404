<?php
	$conn= mysqli_connect('localhost', 'root', '','perpustakaan2');
	
	$id_buku=$_GET['id_buku'];
	$hapus="delete from buku where id_buku='$id_buku'";
	$data=mysqli_query($conn,$hapus);
	
	if($data > 0){
		echo "
		<script>
		alert('data berhasil di hapus');
		document.location.href='edit_buku.php';
		</script>";
	}else
		echo "
		<script>
		alert('data gagal di hapus');
		document.location.href='edit_buku.php';
		</script>";
?>