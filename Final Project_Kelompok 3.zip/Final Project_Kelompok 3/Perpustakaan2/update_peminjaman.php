<?php
	$conn= mysqli_connect('localhost', 'root', '','perpustakaan2');
	
	$id_pinjam = $_POST['id_pinjam'];
    $nim_mahasiswaFK = $_POST['nim_mahasiswaFK'];
    $id_petugasFK = $_POST['id_petugasFK'];
	$tgl_pinjam = $_POST['tgl_pinjam'];
	$jumlah_pinjam = $_POST['jumlah_pinjam'];
    $batas_pinjam = $_POST['batas_pinjam'];
	$submit = $_POST['submit'];
	$update = "UPDATE peminjaman set id_pinjam='$id_pinjam', nim_mahasiswaFK='$nim_mahasiswaFK', id_petugasFK='$id_petugasFK', tgl_pinjam='$tgl_pinjam', jumlah_pinjam=$jumlah_pinjam, batas_pinjam='$batas_pinjam' WHERE id_pinjam='$id_pinjam' ";
	
	if($submit){
		if ($id_pinjam=''){
			echo "ID Pinjam tidak boleh kosong, diisi dulu";
		}elseif ($nim_mahasiswaFK=''){
			echo "Nim Mahasiswa tidak boleh kosong";
        }elseif ($id_petugasFK=''){
			echo "ID Petugas tidak boleh kosong";
		}elseif ($tgl_pinjam=''){
			echo "Tanggal Pinjam tidak boleh kosong";
		}elseif ($jumlah_pinjam=''){
			echo "Jumlah Pinjam tidak boleh kosong";
        }elseif ($batas_pinjam=''){
			echo "Batas Pinjam tidak boleh kosong";
        }else
			mysqli_query($conn,$update);
			echo "
			<script>
			alert('data berhasil di update');
			document.location.href='edit_peminjaman.php';
			</script>";
		}
	
?>