		<?php
			$conn = mysqli_connect('localhost', 'root','','perpustakaan2');
			$id_buku = $_GET['id_buku'];
			$cari = "select * from buku where id_buku = '$id_buku'";
			$hasil_cari = mysqli_query($conn,$cari);
			$data = mysqli_fetch_array($hasil_cari);
			function active_radio_button($value,$input){
				$result = $value==$input? 'checked':'';
				return $result;
			}
			
			if($data > 0){		
			
		?>
<html>
	<head>
		<title>Data Buku</title>
		<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        
        h3 {
            color: #333;
        }
        
        table {
            margin: 20px;
            background-color: #fff;
            border-collapse: collapse;
            width: 400px;
        }
        
        table td {
            padding: 8px;
        }
        
        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        
        input[type="text"],
        input[type="submit"] {
            padding: 5px;
            width: 200px;
        }
        
        input[type="submit"] {
            background-color: #4CAF50;
            color: #ffffff;
            border: none;
            cursor: pointer;
        }
    </style>
	</head>				
			<body>
				<h3>FORM Buku</h3>
				<table>
					<form method="POST" action="update_buku.php">
					<tr>
						<td>ID Buku</td>
						<td>:</td>
						<td><input type="text" name="id_buku" size="10" value="<?php echo $data['id_buku']?>"></td>
					</tr>
                    <tr>
						<td>ID Penerbit</td>
						<td>:</td>
						<td><input type="text" name="id_penerbitFK" size="30" value="<?=$data['id_penerbitFK']?>"></td>
					</tr>
					<tr>
						<td>Nama Buku</td>
						<td>:</td>
						<td><input type="text" name="nama_buku" size="30" value="<?=$data['nama_buku']?>"></td>
					</tr>
					<tr>
						<td>Jumlah Buku</td>
						<td>:</td>
						<td><input type="text" name="jumlah_buku" size="30" value="<?=$data['jumlah_buku']?>"></td>
						</td>
					</tr>
                    <tr>
						<td>Tahun Terbit</td>
						<td>:</td>
						<td><input type="text" name="tahun_terbit" size="30" value="<?=$data['tahun_terbit']?>"></td>
					</tr>
					<tr>
						<td><input type="submit" name="submit" value="UPDATE DATA"></td>
					</tr>
					</form>
				</table>
			<?php
			}
			?>
				
			</body>
	</html>