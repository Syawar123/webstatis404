<!DOCTYPE html>
<html>

<head>
  <title>Home</title>
  <style>
    /* Reset CSS */
    body,
    h1,
    h2,
    h3,
    p,
    ul,
    li,
    a {
      margin: 0;
      padding: 0;
    }

    /* Styles Tubuh */
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      color: #333;
    }

    /* Styles Header */
    header {
      background-color: #333;
      padding: 10px;
      text-align: center;
    }

    header h1 {
      color: #fff;
      font-size: 36px;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 10px;
    }

    /* Styles Konten */
    #content {
      padding: 20px;
      max-width: 600px;
      margin: 0 auto;
      text-align: center;
    }

    .logout {
      text-align: right;
    }

    button {
      background-color: white;
      border-color: blue;
    }

    .logo {
      margin-bottom: 20px;
    }

    .logo img {
      width: 100px;
    }

    h2 {
      font-size: 24px;
      margin-bottom: 20px;
      color: #333;
      text-transform: uppercase;
      letter-spacing: 2px;
    }

    #buku,
    #peminjaman,
    #pengembalian {
      margin-top: 40px;
      background-color: #fff;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    #buku h3,
    #peminjaman h3,
    #pengembalian h3 {
      font-size: 20px;
      margin-bottom: 10px;
      color: #333;
      text-transform: uppercase;
      letter-spacing: 2px;
    }

    #buku p,
    #peminjaman p,
    #pengembalian p {
      margin-bottom: 10px;
      color: #555;
    }

    #buku a,
    #peminjaman a,
    #pengembalian a {
      display: inline-block;
      background-color: #ff9800;
      color: #fff;
      padding: 12px 24px;
      text-decoration: none;
      border-radius: 4px;
      transition: background-color 0.3s ease;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-weight: bold;
      text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    #buku a:hover,
    #peminjaman a:hover,
    #pengembalian a:hover {
      background-color: #e65100;
    }

  </style>
</head>

<body>

  <header>
    <div class="logout">
      <button><a href="index.php">Logout</a></button>
    </div>
    <div class="logo">
      <img src="ums.png" alt="Logo Perpustakaan">
    </div>
    <h1>Perpustakaan Online</h1>
  </header>

  <section id="content">
    <h2>Selamat datang di Perpustakaan</h2>

    <div id="buku">
      <h3>Kelola Buku</h3>
      <p>Halaman Kelola Buku</p>
      <a href="edit_buku.php">Edit Buku</a>
    </div>

    <div id="peminjaman">
      <h3>Peminjaman</h3>
      <p>Halaman Edit Peminjaman.</p>
      <a href="edit_peminjaman.php">Pinjam Buku</a>
    </div>

    <div id="pengembalian">
      <h3>Pengembalian</h3>
      <p>Halaman Edit Pengembalian.</p>
      <a href="edit_pengembalian.php">Kembalikan Buku</a>
    </div>
  </section>
</body>

</html>