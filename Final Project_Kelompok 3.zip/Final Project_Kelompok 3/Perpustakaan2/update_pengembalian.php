<?php
	$conn= mysqli_connect('localhost', 'root', '','perpustakaan2');
	
	$id_kembali = $_POST['id_kembali'];
    $nim_mahasiswaFK = $_POST['nim_mahasiswaFK'];
    $id_petugasFK = $_POST['id_petugasFK'];
	$tgl_pinjamFK = $_POST['tgl_pinjamFK'];
	$jumlah_kembali = $_POST['jumlah_kembali'];
    $tgl_kembali = $_POST['tgl_kembali'];
    $status = $_POST['status'];
	$submit = $_POST['submit'];
	$update = "UPDATE pengembalian set id_kembali='$id_kembali', nim_mahasiswaFK='$nim_mahasiswaFK', id_petugasFK='$id_petugasFK', tgl_pinjamFK='$tgl_pinjamFK', jumlah_kembali=$jumlah_kembali, tgl_kembali='$tgl_kembali', status='$status' WHERE id_kembali='$id_kembali' ";
	
	if($submit){
		if ($id_kembali=''){
			echo "ID Pinjam tidak boleh kosong, diisi dulu";
		}elseif ($nim_mahasiswaFK=''){
			echo "Nim Mahasiswa tidak boleh kosong";
        }elseif ($id_petugasFK=''){
			echo "ID Petugas tidak boleh kosong";
		}elseif ($tgl_pinjamFK=''){
			echo "Tanggal Pinjam tidak boleh kosong";
		}elseif ($jumlah_kembali=''){
			echo "Jumlah Kembali tidak boleh kosong";
        }elseif ($tgl_kembali=''){
			echo "Tanggal Kembali tidak boleh kosong";
        }elseif ($status=''){
			echo "Status tidak boleh kosong";
        }else
			mysqli_query($conn,$update);
			echo "
			<script>
			alert('data berhasil di update');
			document.location.href='edit_pengembalian.php';
			</script>";
		}
	
?>