<?php
	$conn= mysqli_connect('localhost', 'root', '','perpustakaan2');
?>
<html>
<head>
	<title>Data Peminjaman</title>
    <style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 20px;
            background-image: linear-gradient(to top, #9be15d 0%, #00e3ae 100%);
		}

		h1 {
            text-align: center;
		}

		table {
            margin: 20px auto;
			border-collapse: collapse;
			width: 100%;
		}

		table, td, th {
			border: 1px solid black;
            padding: 8px;
		}

		input[type="text"] {
			width: 98%;
			padding: 5px;
		}

		input[type="submit"], button {
			padding: 10px 20px;
			border: none;
			background-color: #4CAF50;
			color: white;
			cursor: pointer;
		}
        input[type="submit"]:hover {
              background-color: grey;
        }

		button {
			background-color: #008CBA;
		}

        button:hover {
            background-color: grey;
        }

		a {
			color: white;
			text-decoration: none;
		}
	</style>
</head>
<body>
    <h1>Masukkan Data Peminjaman</h1>
        <table border='0' width='30%'>
        <form method='post' action='edit_peminjaman.php'>
            <tr>
                <td width='25%'>ID Pinjam</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='id_pinjam' size='100'></td>
            </tr>
            <tr>
                <td width='25%'>Nim Mahasiswa</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='nim_mahasiswaFK' size='100'></td>
            </tr>
            <tr>
                <td width='25%'>ID Petugas</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='id_petugasFK' size='100'></td>
            </tr>
            <tr>
                <td width='25%'>Tanggal Pinjam</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='tgl_pinjam' size='100'></td>
            </tr>
            <tr>
                <td width='25%'>Jumlah Pinjam</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='jumlah_pinjam' size='100'></td>
            </tr>
            <tr>
                <td width='25%'>Batas Pinjam</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='batas_pinjam' size='100'></td>
            </tr>
        </table>
        <br>
        <input type='submit' value='Tambah Data Peminjaman' name='submit'>
        <button><a href="admin1.php">Kembali</a></button>
        </form>
     <?php
            error_reporting(E_ALL^E_NOTICE);
            $id_pinjam = isset($_POST['id_pinjam']) ? $_POST['id_pinjam'] : '';
            $nim_mahasiswaFK = isset($_POST['nim_mahasiswaFK']) ? $_POST['nim_mahasiswaFK'] : '';
            $id_petugasFK = isset($_POST['id_petugasFK']) ? $_POST['id_petugasFK'] : '';
            $tgl_pinjam = isset($_POST['tgl_pinjam']) ? $_POST['tgl_pinjam'] : '';
            $jumlah_pinjam = isset($_POST['jumlah_pinjam']) ? $_POST['jumlah_pinjam'] : '';
            $batas_pinjam = isset($_POST['batas_pinjam']) ? $_POST['batas_pinjam'] : '';
            $submit = isset($_POST['submit']) ? $_POST['submit'] : '';
            $input = "insert into peminjaman (id_pinjam, nim_mahasiswaFK, id_petugasFK, tgl_pinjam, jumlah_pinjam, batas_pinjam) values ('$id_pinjam', '$nim_mahasiswaFK', '$id_petugasFK', '$tgl_pinjam', $jumlah_pinjam, '$batas_pinjam')";
             if($submit){
                mysqli_query($conn,$input);
                echo'</br>Data berhasil dimasukkan';
            }
        ?>

        <h2> Data Peminjaman <h2>
        <table border='1'>
            <tr>
                <td>ID Peminjaman</td>
                <td>NIM Mahasiswa</td>
                <td>ID Petugas</td>
                <td>Tanggal Pinjam</td>
                <td>Jumlah Pinjam</td>
                <td>Batas Pinjam</td>
                <td colspan=2 align="center">Action</td>
            </tr>

		<?php
            $cari = "select * from peminjaman order by id_pinjam";
            $hasil_cari = mysqli_query($conn,$cari);
            while ($data = mysqli_fetch_array($hasil_cari)){
                echo"<tr>
                    <td>$data[id_pinjam]</td>
                    <td>$data[nim_mahasiswaFK]</td>
                    <td>$data[id_petugasFK]</td>
                    <td>$data[tgl_pinjam]</td>
                    <td>$data[jumlah_pinjam]</td>
                    <td>$data[batas_pinjam]</td>
                    <td><button><a href='update_form_peminjaman.php?id_pinjam=$data[id_pinjam]'>Edit</a></button></td>
                    <td><button><a href='delete_peminjaman.php?id_pinjam=$data[id_pinjam]'>Delete</a></button></td>
                    </tr>";
            }
		?>
	</table>
	</body>
</html>