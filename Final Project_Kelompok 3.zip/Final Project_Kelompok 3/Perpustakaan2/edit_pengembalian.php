<?php
	$conn= mysqli_connect('localhost', 'root', '','perpustakaan2');
?>
<html>
<head>
	<title>Data Pengembalian</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-image: linear-gradient(to top, #9be15d 0%, #00e3ae 100%);
        }

        h1 {
            text-align: center;
        }
        
        table {
            margin: 20px auto;
            border-collapse: collapse;
            width: 100%;
        }

        table, td, th {
            border: 1px solid black;
            padding: 8px;
        }

        input[type="text"] {
            width: 98%;
            padding: 5px;
        }

        input[type="submit"], button {
			padding: 10px 20px;
			border: none;
			background-color: #4CAF50;
			color: white;
			cursor: pointer;
		}
        input[type="submit"]:hover {
              background-color: grey;
        }

        a {
            text-decoration: none;
            color: white;
        }

        button {
			background-color: #008CBA;
		}
        button:hover {
            background-color: grey;
        }
    </style>
</head>
<body>
    <h1>Masukkan Data Pengembalian</h1>
        <table border='0' width='30%'>
        <form method='post' action='edit_pengembalian.php'>
            <tr>
                <td width='25%'>ID Kembali</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='id_kembali' size='10'></td>
            </tr>
            <tr>
                <td width='25%'>Nim Mahasiswa</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='nim_mahasiswaFK' size='10'></td>
            </tr>
            <tr>
                <td width='25%'>ID Petugas</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='id_petugasFK' size='10'></td>
            </tr>
            <tr>
                <td width='25%'>Tanggal Pinjam</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='tgl_pinjamFK' size='30'></td>
            </tr>
            <tr>
                <td width='25%'>Jumlah Kembali</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='jumlah_kembali' size='10'></td>
            </tr>
            <tr>
                <td width='25%'>Tanggal Kembali</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='tgl_kembali' size='30'></td>
            </tr>
            <tr>
                <td width='25%'>status</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='status' size='40'></td>
            </tr>
        </table>
        <br>
        <input type='submit' value='Tambah Data Pengembalian' name='submit'>
        <button><a href="admin1.php">Kembali</a></button>
        </form>
     <?php
            error_reporting(E_ALL^E_NOTICE);
            $id_kembali = isset($_POST['id_kembali']) ? $_POST['id_kembali'] : '';
            $nim_mahasiswaFK = isset($_POST['nim_mahasiswaFK']) ? $_POST['nim_mahasiswaFK'] : '';
            $id_petugasFK = isset($_POST['id_petugasFK']) ? $_POST['id_petugasFK'] : '';
            $tgl_pinjamFK = isset($_POST['tgl_pinjamFK']) ? $_POST['tgl_pinjamFK'] : '';
            $jumlah_kembali = isset($_POST['jumlah_kembali']) ? $_POST['jumlah_kembali'] : '';
            $tgl_kembali = isset($_POST['tgl_kembali']) ? $_POST['tgl_kembali'] : '';
            $status = isset($_POST['status']) ? $_POST['status'] : '';
            $submit = isset($_POST['submit']) ? $_POST['submit'] : '';
            $input = "insert into pengembalian (id_kembali, nim_mahasiswaFK, id_petugasFK, tgl_pinjamFK, jumlah_kembali, tgl_kembali, status) values ('$id_kembali', '$nim_mahasiswaFK', '$id_petugasFK', '$tgl_pinjamFK', $jumlah_kembali, '$tgl_kembali', '$status')";
             if($submit){
                mysqli_query($conn,$input);
                echo'</br>Data berhasil dimasukkan';
            }
        ?>
        <h2> Data Pengembalian </h2>
        <table border='1'>
            <tr>
                <td>ID Pengembalian</td>
                <td>NIM Mahasiswa</td>
                <td>ID Petugas</td>
                <td>Tanggal Pinjam</td>
                <td>Jumlah Kembali</td>
                <td>Tanggal Kembali</td>
                <td>status</td>
                <td colspan=2 align="center">Action</td>
            </tr>
		<?php
            $cari = "select * from pengembalian order by id_kembali";
            $hasil_cari = mysqli_query($conn,$cari);
            while ($data = mysqli_fetch_array($hasil_cari)){
                echo"<tr>
                    <td>$data[id_kembali]</td>
                    <td>$data[nim_mahasiswaFK]</td>
                    <td>$data[id_petugasFK]</td>
                    <td>$data[tgl_pinjamFK]</td>
                    <td>$data[jumlah_kembali]</td>
                    <td>$data[tgl_kembali]</td>
                    <td>$data[status]</td>
                    <td><button><a href='update_form_pengembalian.php?id_kembali=$data[id_kembali]'>Edit</a></button></td>
                    <td><button><a href='delete_pengembalian.php?id_kembali=$data[id_kembali]'>Delete</a></button></td>
                    </tr>";
            }
		?>
	</table>
	</body>
</html>