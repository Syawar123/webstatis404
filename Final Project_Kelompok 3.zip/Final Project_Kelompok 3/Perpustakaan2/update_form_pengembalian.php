		<?php
			$conn = mysqli_connect('localhost', 'root','','perpustakaan2');
			$id_kembali = $_GET['id_kembali'];
			$cari = "select * from pengembalian where id_kembali = '$id_kembali'";
			$hasil_cari = mysqli_query($conn,$cari);
			$data = mysqli_fetch_array($hasil_cari);
			function active_radio_button($value,$input){
				$result = $value==$input? 'checked':'';
				return $result;
			}
			
			if($data > 0){		
			
		?>
<html>
	<head>
		<title>Data Pengembalian</title>
		<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        
        h3 {
            color: #333;
        }
        
        table {
            margin: 20px;
            background-color: #fff;
            border-collapse: collapse;
            width: 400px;
        }
        
        table td {
            padding: 8px;
        }
        
        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        
        input[type="text"],
        input[type="submit"] {
            padding: 5px;
            width: 200px;
        }
        
        input[type="submit"] {
            background-color: #4CAF50;
            color: #ffffff;
            border: none;
            cursor: pointer;
        }
    </style>
	</head>				
			<body>
				<h3>FORM Pengembalian</h3>
				<table>
					<form method="POST" action="update_pengembalian.php">
					<tr>
						<td>ID Kembali</td>
						<td>:</td>
						<td><input type="text" name="id_kembali" size="10" value="<?php echo $data['id_kembali']?>"></td>
					</tr>
                    <tr>
						<td>Nim Mahasiswa</td>
						<td>:</td>
						<td><input type="text" name="nim_mahasiswaFK" size="30" value="<?=$data['nim_mahasiswaFK']?>"></td>
					</tr>
					<tr>
						<td>ID Petugas</td>
						<td>:</td>
						<td><input type="text" name="id_petugasFK" size="30" value="<?=$data['id_petugasFK']?>"></td>
					</tr>
                    <tr>
						<td>Tanggal Pinjam</td>
						<td>:</td>
						<td><input type="text" name="tgl_pinjamFK" size="30" value="<?=$data['tgl_pinjamFK']?>"></td>
						</td>
					</tr>
					<tr>
						<td>Jumlah Kembali</td>
						<td>:</td>
						<td><input type="text" name="jumlah_kembali" size="30" value="<?=$data['jumlah_kembali']?>"></td>
						</td>
					</tr>
                    <tr>
						<td>Tanggal Kembali</td>
						<td>:</td>
						<td><input type="text" name="tgl_kembali" size="30" value="<?=$data['tgl_kembali']?>"></td>
						</td>
					</tr>
                    <tr>
						<td>status</td>
						<td>:</td>
						<td><input type="text" name="status" size="30" value="<?=$data['status']?>"></td>
					</tr>
					<tr>
						<td><input type="submit" name="submit" value="UPDATE DATA"></td>
					</tr>
					</form>
				</table>
			<?php
			}
			?>
				
			</body>
	</html>