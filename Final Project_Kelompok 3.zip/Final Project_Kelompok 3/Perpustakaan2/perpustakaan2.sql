-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2023 at 12:21 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan2`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` varchar(20) NOT NULL,
  `id_penerbitFK` varchar(20) NOT NULL,
  `nama_buku` varchar(255) NOT NULL,
  `jumlah_buku` int(11) NOT NULL,
  `tahun_terbit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `id_penerbitFK`, `nama_buku`, `jumlah_buku`, `tahun_terbit`) VALUES
('B103', 'PT10', 'Rain affair ketika hujan aku jatuh cinta', 5, 2010),
('B112', 'PT10', 'Buku Rahasia Geez', 3, 2018),
('B13', 'PT01', 'Masih Ingatkah Kau Jalan Pulang', 7, 2020),
('B18', 'PT01', 'Keajaiban Toko Kelontong Namiya', 5, 2021),
('B20', 'PT02', 'Ulysses Moore: pintu waktu', 4, 2006),
('B22', 'PT02', 'Ensiklopedia mini hewan', 6, 2003),
('B37', 'PT03', 'Seni Merayu Tuhan', 5, 2019),
('B44', 'PT04', 'Laskar Pelangi', 3, 2005),
('B47', 'PT04', 'Arah Musim', 4, 2019),
('B51', 'PT05', 'Rindu Pancasila merajut Nusantara', 6, 2010),
('B52', 'PT05', 'Sehat itu murah', 2, 2006),
('B63', 'PT06', 'Musim yang bercerita tentang cinta', 4, 2014),
('B64', 'PT06', 'Kotak Waktu', 5, 2019),
('B75', 'PT07', 'No Place Like Home', 2, 2017),
('B78', 'PT07', 'Namaku Merah', 5, 2015),
('B81', 'PT08', 'Masa Depan Dunia Setelah Covid-19', 6, 2020),
('B83', 'PT08', 'Sejarah Dunia yang Disembunyikan', 3, 2015),
('B94', 'PT09', 'Hukum Surat Berharga', 2, 2022),
('B97', 'PT09', 'Keadilan Sosial Bagi Kaum Tertindas', 4, 2022);

-- --------------------------------------------------------

--
-- Table structure for table `buku_has_peminjaman`
--

CREATE TABLE `buku_has_peminjaman` (
  `id_bukuFK` varchar(20) NOT NULL,
  `id_pinjamFK` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku_has_peminjaman`
--

INSERT INTO `buku_has_peminjaman` (`id_bukuFK`, `id_pinjamFK`) VALUES
('B18', 'C123'),
('B22', 'C123'),
('B38', 'C256'),
('B13', 'C341'),
('B22', 'C341'),
('B37', 'C341'),
('B13', 'C423'),
('B51', 'C423'),
('B52', 'C423'),
('B13', 'C423'),
('B22', 'C572'),
('B37', 'C654'),
('B51', 'C762'),
('B64', 'C762'),
('B63', 'C478'),
('B81', 'C945'),
('B94', 'C945'),
('B63', 'C945'),
('B94', 'C109'),
('B22', 'C109'),
('B37', 'C165'),
('B97', 'C165'),
('B103', 'C165'),
('B112', 'C165'),
('B112', 'C203'),
('B97', 'C203'),
('B103', 'C203'),
('B51', 'C203'),
('B97', 'C319'),
('B103', 'C319'),
('B81', 'C319'),
('B103', 'C407'),
('B81', 'C223'),
('B13', 'C223'),
('B18', 'C223'),
('B64', 'C545'),
('B83', 'C545'),
('B75', 'C167'),
('B44', 'C167'),
('B18', 'C328'),
('B20', 'C328'),
('B44', 'C328'),
('B47', 'C876'),
('B78', 'C801'),
('B47', 'C801'),
('B20', 'C801'),
('B18', 'C801');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `status`) VALUES
('Budi Susanto', 'A1', 'admin'),
('Amanah Endah', 'C100180052', 'mahasiswa');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim_mahasiswa` varchar(20) NOT NULL,
  `nama_mahasiswa` varchar(255) NOT NULL,
  `jurusan` varchar(45) NOT NULL,
  `gender_mahasiswa` varchar(1) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim_mahasiswa`, `nama_mahasiswa`, `jurusan`, `gender_mahasiswa`, `status`) VALUES
('C100180052', 'Amanah Endah', 'Hukum', 'P', 'mahasiswa'),
('C100180237', 'Intan Ayuni', 'Hukum', 'P', 'mahasiswa'),
('C100190138', 'Ryzdha Ashvin', 'Hukum', 'L', 'mahasiswa'),
('C100190193', 'Marfela Randy', 'Hukum', 'P', 'mahasiswa'),
('C100190220', 'Cantika Clara', 'Hukum', 'P', 'mahasiswa'),
('D100180148', 'Sekar Rengganis', 'Teknik Sipil', 'P', 'mahasiswa'),
('D100190023', 'Lintang Pramudya', 'Teknik Sipil', 'L', 'mahasiswa'),
('D100190092', 'Fernanda Aldy', 'Teknik Sipil', 'L', 'mahasiswa'),
('D400180132', 'Ayudia Medari', 'Teknik Elektro', 'P', 'mahasiswa'),
('D500180019', 'Nurul Fatimah', 'Teknik Kimia', 'P', 'mahasiswa'),
('D500180042', 'Fajar Nugroho', 'Tehnik Kimia', 'L', 'mahasiswa'),
('D500180111', 'Theo Vedo', 'Tehnik Kimia', 'L', 'mahasiswa'),
('D500190027', 'Adinda Sari', 'Tehnik Kimia', 'P', 'mahasiswa'),
('D500190247', 'Puspita Lestari', 'Tehnik Kimia', 'P', 'mahasiswa'),
('D600180182', 'Budi Haryanto', 'Teknik Industri', 'L', 'mahasiswa'),
('D600190156', 'Mekar Andini', 'Teknik Industri', 'P', 'mahasiswa'),
('L100180013', 'Rega Alif', 'Ilmu Komunikasi', 'L', 'mahasiswa'),
('L100180036', 'Adrian Rakha', 'Ilmu Komunikasi', 'L', 'mahasiswa'),
('L100180162', 'Safira Candra', 'Ilmu Komunikasi', 'P', 'mahasiswa'),
('L200180222', 'Muhammad Akbar', 'Informatika', 'L', 'mahasiswa'),
('L200180265', 'Anggun Padi C', 'Informatika', 'P', 'mahasiswa'),
('L200190021', 'Karenina Cahya', 'Informatika', 'L', 'mahasiswa'),
('L200190045', 'Jurdhavianto', 'Informatika', 'L', 'mahasiswa'),
('L200190087', 'Marchel Huda', 'Informatika', 'L', 'mahasiswa'),
('L200190135', 'Juwanda', 'Informatika', 'L', 'mahasiswa');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_pinjam` varchar(20) NOT NULL,
  `nim_mahasiswaFK` varchar(20) NOT NULL,
  `id_petugasFK` varchar(20) NOT NULL,
  `tgl_pinjam` datetime NOT NULL,
  `jumlah_pinjam` int(11) NOT NULL,
  `batas_pinjam` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`id_pinjam`, `nim_mahasiswaFK`, `id_petugasFK`, `tgl_pinjam`, `jumlah_pinjam`, `batas_pinjam`) VALUES
('C109', 'C100190138', 'A10', '2023-01-12 00:00:00', 2, '2023-01-16 00:00:00'),
('C123', 'C100180052', 'A1', '2023-01-10 00:00:00', 2, '2023-01-14 00:00:00'),
('C165', 'D500180042', 'A2', '2023-01-15 00:00:00', 4, '2023-01-19 00:00:00'),
('C167', 'D500190027', 'A5', '2023-02-03 00:00:00', 2, '2023-02-07 00:00:00'),
('C203', 'D500180111', 'A4', '2023-01-16 00:00:00', 4, '2023-01-20 00:00:00'),
('C223', 'L200180222', 'A1', '2023-01-26 00:00:00', 3, '2023-01-30 00:00:00'),
('C256', 'D100180148', 'A9', '2023-01-10 00:00:00', 1, '2023-01-14 00:00:00'),
('C319', 'L200190021', 'A6', '2023-01-22 00:00:00', 3, '2023-01-26 00:00:00'),
('C328', 'C100190138', 'A7', '2023-02-10 00:00:00', 3, '2023-02-14 00:00:00'),
('C341', 'L200190087', 'A2', '2023-01-10 00:00:00', 3, '2023-01-14 00:00:00'),
('C407', 'L200180265', 'A8', '2023-01-22 00:00:00', 1, '2023-01-26 00:00:00'),
('C423', 'L200190135', 'A8', '2023-01-10 00:00:00', 4, '2023-01-14 00:00:00'),
('C478', 'L200190045', 'A6', '2023-01-11 00:00:00', 1, '2023-01-15 00:00:00'),
('C545', 'D600190156', 'A3', '2023-02-01 00:00:00', 2, '2023-02-04 00:00:00'),
('C572', 'D600180182', 'A3', '2023-01-11 00:00:00', 1, '2023-01-15 00:00:00'),
('C654', 'C100190220', 'A7', '2023-01-11 00:00:00', 1, '2023-01-15 00:00:00'),
('C762', 'D500180019', 'A4', '2023-01-11 00:00:00', 2, '2023-01-15 00:00:00'),
('C801', 'L100180036', 'A10', '2023-02-11 00:00:00', 4, '2023-02-15 00:00:00'),
('C876', 'C100190193', 'A9', '2023-02-10 00:00:00', 1, '2023-02-14 00:00:00'),
('C945', 'C100180237', 'A5', '2023-01-12 00:00:00', 3, '2023-01-16 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `penerbit`
--

CREATE TABLE `penerbit` (
  `id_penerbit` varchar(20) NOT NULL,
  `nama_penerbit` varchar(255) NOT NULL,
  `alamat_penerbit` varchar(255) NOT NULL,
  `email_penerbit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penerbit`
--

INSERT INTO `penerbit` (`id_penerbit`, `nama_penerbit`, `alamat_penerbit`, `email_penerbit`) VALUES
('PT01', 'PT Gramedia Pustaka Utama', 'Jl. Palmerah Barat No.110, Jakarta 10270', 'info@gramediapublishers.com'),
('PT02', 'PT. Penerbit Erlangga', 'Jl. H. Baping Raya No. 100 Ciracas, Jakarta Timur', 'support@erlangga.co.id'),
('PT03', 'PT Mizan Pustaka', 'Jl. Daan Mogot Km. 14, Kalideres, Jakarta 11840', 'pustaka@mizan.com'),
('PT04', 'PT Bentang Pustaka', 'Jl. Balai Pustaka Timur Blok D2-D3, Rawamangun, Jakarta 13220', 'info@bentangpustaka.com'),
('PT05', 'PT Kompas Media Nusantara', 'Jl. Palmerah Selatan No. 22-28, Jakarta 10270', 'info@kompas.com'),
('PT06', 'PT Elex Media Komputindo', 'Jl. Proklamasi No. 56, Jakarta 10320', 'info@elexmedia.co.id'),
('PT07', 'PT Serambi Ilmu Semesta', 'Jl. Cempaka Putih Tengah XIII No. 3, Jakarta 10520', 'info@serambi.co.id'),
('PT08', 'PT Pustaka Alvabet', 'Jl. Tebet Barat III No. 1, Jakarta Selatan 12810', 'info@pustakaalvabet.com'),
('PT09', 'PT Pustaka Pelajar', 'Jl. Manggarai Raya No. 4, Jakarta Selatan 12730', 'info@pustakapelajar.com'),
('PT10', 'PT GagasMedia', 'Jl. Kramat Raya No. 43, Jakarta Pusat 10450', 'info@gagasmedia.net');

-- --------------------------------------------------------

--
-- Table structure for table `pengembalian`
--

CREATE TABLE `pengembalian` (
  `id_kembali` varchar(20) NOT NULL,
  `id_petugasFK` varchar(20) NOT NULL,
  `nim_mahasiswaFK` varchar(20) NOT NULL,
  `tgl_pinjamFK` datetime NOT NULL,
  `jumlah_kembali` int(11) NOT NULL,
  `tgl_kembali` datetime NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengembalian`
--

INSERT INTO `pengembalian` (`id_kembali`, `id_petugasFK`, `nim_mahasiswaFK`, `tgl_pinjamFK`, `jumlah_kembali`, `tgl_kembali`, `status`) VALUES
('D1090', 'A9', 'C100190138', '2023-01-12 00:00:00', 2, '2023-01-16 00:00:00', 'sudah'),
('D1230', 'A2', 'C100180052', '2023-01-10 00:00:00', 2, '2023-01-14 00:00:00', 'sudah'),
('D1650', 'A10', 'D500180042', '2023-01-15 00:00:00', 4, '2023-01-19 00:00:00', 'sudah'),
('D2030', 'A2', 'D500180111', '2023-01-16 00:00:00', 4, '2023-01-20 00:00:00', 'sudah'),
('D2230', 'A1', 'L200180222', '2023-01-26 00:00:00', 3, '2023-01-30 00:00:00', 'sudah'),
('D2560', 'A4', 'D100180148', '2023-01-10 00:00:00', 1, '2023-01-17 00:00:00', 'sudah (terlambat)'),
('D3190', 'A3', 'L200190021', '2023-01-22 00:00:00', 3, '2023-01-29 00:00:00', 'sudah (terlambat)'),
('D3410', 'A6', 'L200190087', '2023-01-10 00:00:00', 3, '2023-01-14 00:00:00', 'sudah'),
('D4070', 'A5', 'L200180265', '2023-01-22 00:00:00', 1, '2023-01-26 00:00:00', 'sudah'),
('D4230', 'A8', 'L200190135', '2023-01-10 00:00:00', 4, '2023-01-14 00:00:00', 'sudah'),
('D4780', 'A5', 'L200190045', '2023-01-11 00:00:00', 1, '2023-01-15 00:00:00', 'sudah'),
('D5720', 'A10', 'D600180182', '2023-01-11 00:00:00', 1, '2023-01-18 00:00:00', 'sudah (terlambat)'),
('D6540', 'A1', 'C100190220', '2023-01-11 00:00:00', 1, '2023-01-15 00:00:00', 'sudah'),
('D7620', 'A3', 'D500180019', '2023-01-11 00:00:00', 2, '2023-01-15 00:00:00', 'sudah'),
('D9450', 'A7', 'C100180237', '2023-01-12 00:00:00', 3, '2023-01-20 00:00:00', 'sudah (terlambat)');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` varchar(20) NOT NULL,
  `nama_petugas` varchar(255) NOT NULL,
  `alamat_petugas` varchar(255) NOT NULL,
  `gender_petugas` varchar(1) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `nama_petugas`, `alamat_petugas`, `gender_petugas`, `status`) VALUES
('A1', 'Budi Susanto', 'Jl. Diponegoro No. 123', 'L', 'admin'),
('A10', 'Ratna Kusuma', 'Jl. Gatot Subroto No. 573', 'P', 'admin'),
('A2', 'Anita Sari', 'Jl. Sudirman No. 456', 'P', 'admin'),
('A3', 'Ahmad Hidayat', 'Jl. Ahmad Yani No. 789', 'L', 'admin'),
('A4', 'Rina Wijaya', 'Jl. Merdeka No. 321', 'P', 'admin'),
('A5', 'Eko Prasetyo', 'Jl. Gajah Mada No. 654', 'L', 'admin'),
('A6', 'Siti Rahayu', 'Jl. Asia Afrika No. 987', 'P', 'admin'),
('A7', 'Joko Santoso', 'Jl. Veteran No. 135', 'L', 'admin'),
('A8', 'Dewi Indah', 'Jl. Pahlawan No. 864', 'P', 'admin'),
('A9', 'Hendra Wijaya', 'Jl. Raya Bogor No. 246', 'L', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`password`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim_mahasiswa`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_pinjam`);

--
-- Indexes for table `penerbit`
--
ALTER TABLE `penerbit`
  ADD PRIMARY KEY (`id_penerbit`);

--
-- Indexes for table `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD PRIMARY KEY (`id_kembali`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
