<?php
	$conn= mysqli_connect('localhost', 'root', '','perpustakaan2');
	
	$id_kembali=$_GET['id_kembali'];
	$hapus="delete from pengembalian where id_kembali='$id_kembali'";
	$data=mysqli_query($conn,$hapus);
	
	if($data > 0){
		echo "
		<script>
		alert('data berhasil di hapus');
		document.location.href='edit_pengembalian.php';
		</script>";
	}else
		echo "
		<script>
		alert('data gagal di hapus');
		document.location.href='edit_pengembalian.php';
		</script>";
?>