<!DOCTYPE html>
<html>

<head>
    <title>Perpustakaan Online</title>
    <style>
        /* CSS styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: white;
            border-color: blue;
            text-align: right;
        }

        .container {
            width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }

        .book-list {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            grid-gap: 20px;
        }

        .book-item {
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 4px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .book-item:hover {
            transform: translateY(-5px);
        }

        .book-title {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .book-spec {
            font-style: italic;
            color: #777;
        }
    </style>
</head>

<body>
    <header>
        <button><a href="index.php">Logout</a></button>
    </header>


    <div class="container">
        <h1>Perpustakaan Online</h1>


        <div class="book-list">
            <?php
            // Menghubungkan ke database
            $koneksi = mysqli_connect("localhost", "root", "", "perpustakaan2");

            // Mengecek koneksi
            if (mysqli_connect_errno()) {
                echo "Koneksi database gagal: " . mysqli_connect_error();
            }

            // Mengambil data buku dari database
            $query = "SELECT * FROM buku";
            $result = mysqli_query($koneksi, $query);

            // Menampilkan daftar buku
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="book-item">';
                echo '<div class="book-title">' . $row['nama_buku'] . '</div>';
                echo '<div class="book-spec">Jumlah Buku : ' . $row['jumlah_buku'] . '</div>';
                echo '<div class="book-spec">Tahun Terbit : ' . $row['tahun_terbit'] . '</div>';
                echo '</div>';
            }

            // Menutup koneksi database
            mysqli_close($koneksi);
            ?>
        </div>
    </div>
</body>

</html>