<!DOCTYPE html>
<html lang="en">

<head>
    <title>Data Buku</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-image: linear-gradient(to top, #9be15d 0%, #00e3ae 100%);
        }

        h1 {
            text-align: center;
        }
        
        table {
            margin: 20px auto;
            border-collapse: collapse;
            width: 100%;
        }

        table, td, th {
            border: 1px solid black;
            padding: 8px;
        }

        input[type="text"] {
            width: 98%;
            padding: 5px;
        }

        input[type="submit"], button {
			padding: 10px 20px;
			border: none;
			background-color: #4CAF50;
			color: white;
			cursor: pointer;
		}
         input[type="submit"]:hover {
              background-color: grey;
        }

        a {
            text-decoration: none;
            color: white;
        }

        button {
			background-color: #008CBA;  
		}
        button:hover {
            background-color: grey;
        }
    </style>
</head>
<?php
$conn = mysqli_connect('localhost', 'root', '', 'perpustakaan2')
?>

<body>
    <h1>Masukkan Data Buku</h1>
    <table border='0' width='30%'>
        <form method='post' action='edit_buku.php'>
            <tr>
                <td width='25%'>Id Buku</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='id_buku' size='100'></td>
            </tr>
            <tr>
                <td width='25%'>Id Penerbit</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='id_penerbitFK' size='100'></td>
            </tr>
            <tr>
                <td width='25%'>Nama Buku</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='nama_buku' size='100'></td>
            </tr>
            <tr>
                <td width='25%'>Jumlah Buku</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='jumlah_buku' size='100'></td>
            </tr>
            <tr>
                <td width='25%'>Tahun Terbit</td>
                <td width='5%'>:</td>
                <td width='65%'><input type='text' name='tahun_terbit' size='100'></td>
            </tr>
    </table>
    <br>
    <input type='submit' value='Tambah Buku' name='submit'>
    <button><a href="admin1.php">Kembali</a></button>
    </form>
    <?php
    error_reporting(E_ALL ^ E_NOTICE);
    $id_buku = isset($_POST['id_buku']) ? $_POST['id_buku'] : '';
    $nama_buku = isset($_POST['nama_buku']) ? $_POST['nama_buku'] : '';
    $id_penerbitFK = isset($_POST['id_penerbitFK']) ? $_POST['id_penerbitFK'] : '';
    $jumlah_buku = isset($_POST['jumlah_buku']) ? $_POST['jumlah_buku'] : '';
    $tahun_terbit = isset($_POST['tahun_terbit']) ? $_POST['tahun_terbit'] : '';
    $submit = isset($_POST['submit']) ? $_POST['submit'] : '';
    $input = "insert into buku (id_buku, id_penerbitFK, nama_buku, jumlah_buku, tahun_terbit) values ('$id_buku', '$id_penerbitFK', '$nama_buku', $jumlah_buku, $tahun_terbit)";
    if ($submit) {
        mysqli_query($conn, $input);
        echo '</br>Data berhasil dimasukkan';
    }
    ?>

    <h2>View Buku</h2>
    <table border='1'>
        <tr>
            <td>ID Buku</td>
            <td>ID Penerbit</td>
            <td>Nama Buku</td>
            <td>Jumlah Buku</td>
            <td>Tahun Terbit</td>
            <td colspan=2 align="center">Action</td>
        </tr>
        <?php
        $cari = "select * from buku order by id_buku";
        $hasil_cari = mysqli_query($conn, $cari);
        while ($data = mysqli_fetch_array($hasil_cari)) {
            echo "<tr>
                    <td>$data[id_buku]</td>
                    <td>$data[id_penerbitFK]</td>
                    <td>$data[nama_buku]</td>
                    <td>$data[jumlah_buku]</td>
                    <td>$data[tahun_terbit]</td>
                    <td><button><a href='update_form_buku.php?id_buku=$data[id_buku]'>Edit</a></button></td>
                    <td><button><a href='delete_buku.php?id_buku=$data[id_buku]'>Delete</a></button></td>
                    </tr>";
        }
        ?>
</body>

</html>