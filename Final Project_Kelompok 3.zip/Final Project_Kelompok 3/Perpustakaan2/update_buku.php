<?php
	$conn= mysqli_connect('localhost', 'root', '','perpustakaan2');
	
	$id_buku = $_POST['id_buku'];
    $id_penerbitFK = $_POST['id_penerbitFK'];
	$nama_buku = $_POST['nama_buku'];
	$jumlah_buku = $_POST['jumlah_buku'];
    $tahun_terbit = $_POST['tahun_terbit'];
	$submit = $_POST['submit'];
	$update = "UPDATE buku set id_buku='$id_buku', id_penerbitFK='$id_penerbitFK', nama_buku='$nama_buku', jumlah_buku=$jumlah_buku, tahun_terbit=$tahun_terbit WHERE id_buku='$id_buku' ";
	
	if($submit){
		if ($id_buku=''){
			echo "ID buku tidak boleh kosong, diisi dulu";
		}elseif ($id_penerbitFK=''){
			echo "id_penerbit tidak boleh kosong";
        }elseif ($nama_buku=''){
			echo "nama buku tidak boleh kosong";
		}elseif ($jumlah_buku=''){
			echo "jumlah buku tidak boleh kosong";
		}elseif ($tahun_terbit=''){
			echo "tahun terbit tidak boleh kosong";
        }else
			mysqli_query($conn,$update);
			echo "
			<script>
			alert('data berhasil di update');
			document.location.href='edit_buku.php';
			</script>";
		}
	
?>