		<?php
		$conn = mysqli_connect('localhost', 'root', '', 'perpustakaan2');
		$id_pinjam = $_GET['id_pinjam'];
		$cari = "select * from peminjaman where id_pinjam = '$id_pinjam'";
		$hasil_cari = mysqli_query($conn, $cari);
		$data = mysqli_fetch_array($hasil_cari);
		function active_radio_button($value, $input)
		{
			$result = $value == $input ? 'checked' : '';
			return $result;
		}

		if ($data > 0) {

		?>
			<html>

			<head>
				<title>Data Peminjaman</title>
				<style>
					body {
						font-family: Arial, sans-serif;
						background-color: #f2f2f2;
					}

					h3 {
						color: #333;
					}

					table {
						width: 400px;
						margin: 20px;
						background-color: #fff;
						border-collapse: collapse;
					}

					table td {
						padding: 8px;
					}

					table tr:nth-child(even) {
						background-color: #f2f2f2;
					}

					input[type="text"],
					input[type="submit"] {
						padding: 5px;
						width: 200px;
					}

					input[type="submit"] {
						background-color: #4CAF50;
						color: #ffffff;
						border: none;
						cursor: pointer;
					}
				</style>
			</head>

			<body>
				<h3>FORM Peminjaman</h3>
				<table>
					<form method="POST" action="update_peminjaman.php">
						<tr>
							<td>ID Pinjam</td>
							<td>:</td>
							<td><input type="text" name="id_pinjam" size="10" value="<?php echo $data['id_pinjam'] ?>"></td>
						</tr>
						<tr>
							<td>Nim Mahasiswa</td>
							<td>:</td>
							<td><input type="text" name="nim_mahasiswaFK" size="30" value="<?= $data['nim_mahasiswaFK'] ?>"></td>
						</tr>
						<tr>
							<td>ID Petugas</td>
							<td>:</td>
							<td><input type="text" name="id_petugasFK" size="30" value="<?= $data['id_petugasFK'] ?>"></td>
						</tr>
						<tr>
							<td>Tanggal Pinjam</td>
							<td>:</td>
							<td><input type="text" name="tgl_pinjam" size="30" value="<?= $data['tgl_pinjam'] ?>"></td>
							</td>
						</tr>
						<tr>
							<td>Jumlah Pinjam</td>
							<td>:</td>
							<td><input type="text" name="jumlah_pinjam" size="30" value="<?= $data['jumlah_pinjam'] ?>"></td>
							</td>
						</tr>
						<tr>
							<td>Batas Pinjam</td>
							<td>:</td>
							<td><input type="text" name="batas_pinjam" size="30" value="<?= $data['batas_pinjam'] ?>"></td>
						</tr>
						<tr>
							<td><input type="submit" name="submit" value="UPDATE DATA"></td>
						</tr>
					</form>
				</table>
			<?php
		}
			?>

			</body>

			</html>