<?php
session_start();
error_reporting(0);
$koneksi = mysqli_connect('localhost', 'root', '', 'perpustakaan2');

$username = $_POST['username'];
$password = $_POST['password'];
$submit = $_POST['submit'];

if ($submit) {
    $sql = "select * from login where username='$username' and password='$password' ";
    $query = mysqli_query($koneksi, $sql);
    $row = mysqli_fetch_array($query);
    
    if ($row['username'] != "") {
        //berhasil login
        $_SESSION['username'] = $row['username'];
        $_SESSION['status'] = $row['status'];

            if ($_SESSION['status'] == 'mahasiswa') {
                echo "<script>
                    alert('Anda Login Sebagai " . $row['username'] . "');
                    document.location = 'view_buku.php';
                    </script>";
            } else {
                echo "<script>
                    alert('Anda Login Sebagai Admin" . "');
                    document.location = 'admin1.php';
                    </script>";
            }
        
    } else {
        //gagal login
?>
        <script language script="JavaScript">
            alert('Gagal Login');
            document.location = 'index.php';
        </script>
<?php
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login Perpustakaan</title>
    <style>
        /* CSS styling */
        body {
            font-family: karla;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            display: flex;
            align-items: left;
            justify-content: left;
            height: 100vh;
        }

        .login-form {
            width: 50%;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        p {
            text-align: center;
            margin-bottom: 15px;
            color: black;
            font-family: karla;
            font-size: 30px;

        }

        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo img {
            width: 100px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input {
            width: 90%;
            padding: 8px;
            border-radius: 4px;
            border: 5px solid #ccc;
        }

        .button {
            display: block;
            width: 95%;
            padding: 8px;
            background-color: black;
            color: #fff;
            text-decoration: none;
            text-align: center;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: grey;
        }

        .background {
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            width: 100%;
            height: 100%;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="login-form">
            <p>Welcome To Library</p>

            <div class="logo">
                <img src="ums.png" alt="Logo Perpustakaan">
            </div>

            <form method="POST" action="index.php">
                <div class="form-group">
                    <label for="username">username</label>
                    <input type="text" id="username" name="username" required placeholder="username">
                </div>
                <div class="form-group">
                    <label for="password">password</label>
                    <input type="password" id="password" name="password" required placeholder="password">
                </div>
                <input type="submit" name="submit" value="Log In" class="button"></input>
            </form>
        </div>
        <div>
            <img class="background" src="https://asset.kompas.com/crops/Yn331T3ABD2Twkqhp_sO-K0m6Go=/429x39:5529x3439/750x500/data/photo/2021/05/10/609931bb5334c.jpg">
        </div>
    </div>
</body>

</html>