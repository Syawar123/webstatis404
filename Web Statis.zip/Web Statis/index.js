const home = document.getElementById('home');
home.onclick = function() {
    alert('Sudah di Home');
}

const sragen = document.getElementById('S');
sragen.setAttribute('kecamatan','sragen');
sragen.style.fontFamily = 'sans-serif';
sragen.style.fontSize = '14px';

const masaran = document.getElementById('M');
masaran.setAttribute('kecamatan','masaran');
masaran.style.fontFamily = 'sans-serif';
masaran.style.fontSize = '14px';

tombol.onclick = function() {
    document.body.classList.toggle('silver');
}